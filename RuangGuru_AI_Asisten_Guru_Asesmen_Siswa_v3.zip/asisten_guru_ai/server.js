const express = require("express");
const OpenAI = require("openai");
const XLSX = require("xlsx");
const path = require("path");
const app = express();
app.use(express.json({limit:"2mb"}));
app.use(express.static(path.join(__dirname,"public")));

app.post("/api/generate", async (req,res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({error:"API key belum diatur. Jalankan mode demo atau tambahkan OPENAI_API_KEY pada environment."});
  try {
    const client = new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const {kind, data} = req.body;
    const instructions = {
      module: "Susun modul ajar Bahasa Indonesia mengikuti struktur dokumen contoh Modul Pembelajaran STEM/RPP Seni Budaya yang diberikan pengguna. Gunakan urutan dan judul yang rinci: sampul/judul; A. Identitas Mapel; B. Capaian Pembelajaran (CP) beserta elemen dan wujud dalam modul; C. Dimensi Profil Lulusan; D. Desain Pembelajaran (topik proyek/masalah, pertanyaan pemantik, kriteria, batasan, tujuan dan indikator); E. Analisis STEM bila relevan; F. Praktik Pedagogis; G. Pendekatan, Metode, dan Strategi; prinsip pembelajaran; kemitraan, lingkungan dan pemanfaatan digital bila relevan; langkah pembelajaran terperinci per pertemuan dalam tabel/struktur tahapan dengan aktivitas guru, aktivitas murid, media/teknologi, waktu, serta bukti belajar; asesmen diagnostik, formatif, sumatif; instrumen dan rubrik; tindak lanjut/diferensiasi; refleksi guru dan murid; sumber/referensi. Untuk mata pelajaran non-STEM, jangan memaksakan integrasi STEM. Pertahankan istilah pembelajaran mendalam: memahami, mengaplikasi, merefleksi, dan prinsip berkesadaran, bermakna, menggembirakan jika relevan. Jangan mengarang CP resmi; gunakan CP/ATP masukan guru dan tandai bagian yang perlu dilengkapi. Hasilkan dokumen lengkap dengan heading jelas dan tabel berbentuk Markdown jika cocok.",
      questions: "Buat paket soal sesuai format lembar soal contoh pengguna: kop sekolah di tengah (PEMERINTAH PROVINSI JAWA TIMUR, DINAS PENDIDIKAN, SMA NEGERI 1 BULULAWANG, alamat/telepon/email bila diketahui dari contoh), judul penilaian dan mata pelajaran/kelas, baris Nama, Kelas, No. Absen, petunjuk singkat, nomor soal, serta pilihan A-E yang tersusun rapi dan ringkas. Untuk pilihan ganda wajib tepat lima opsi A-E dan satu jawaban benar. Soal cetak harus hanya memuat soal, stimulus, dan opsi—jangan tampilkan kunci, pembahasan, level kognitif, atau indikator pada lembar siswa. Simpan kunci, pembahasan, level kognitif, dan indikator sebagai metadata untuk area guru. Untuk HOTS gunakan stimulus/kasus yang relevan dan pertanyaan analitis; untuk LOTS sesuaikan level yang dipilih. Patuhi CP, ATP, materi, jumlah, dan instruksi guru. Keluarkan JSON valid saja dengan struktur {title, instructions, questions:[{number, stimulus, question, options:{A,B,C,D,E}, answer, explanation, cognitive_level, indicator}]}.",
      rubric: "Buat rubrik penilaian yang adil dan transparan sesuai tugas, CP, ATP, dan kriteria yang diberikan. Keluarkan JSON valid {criteria:[{name,description,weight,levels:[{score,description}]}]}."
    };
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      messages:[
        {role:"system",content:"Anda adalah asisten pedagogis untuk guru Indonesia. Utamakan akurasi, keterlacakan terhadap CP/ATP yang dimasukkan, bahasa yang jelas, dan jangan mengklaim kesesuaian kurikulum tanpa dasar."},
        {role:"user",content:instructions[kind]+"\n\nData guru:\n"+JSON.stringify(data)}
      ],
      temperature:0.4
    });
    res.json({result:completion.choices[0].message.content});
  } catch(e) { res.status(500).json({error:e.message || "Gagal menghubungi layanan AI."}); }
});

app.post("/api/export-xlsx", (req,res) => {
  try {
    const rows = req.body.rows || [];
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Hasil Asesmen");
    const buf = XLSX.write(wb,{type:"buffer",bookType:"xlsx"});
    res.setHeader("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition",'attachment; filename="hasil-asesmen.xlsx"');
    res.send(buf);
  } catch(e) { res.status(500).json({error:e.message}); }
});


// Prototipe asesmen lintas perangkat: data berada di memori server dan hilang saat server restart.
const publishedAssessments = new Map();
function makeCode(){ let code; do { code=String(Math.floor(100000+Math.random()*900000)); } while(publishedAssessments.has(code)); return code; }
app.post("/api/assessments", (req,res)=>{
  const {title, questions, school, subject, grade, assessment}=req.body||{};
  if(!Array.isArray(questions)||!questions.length) return res.status(400).json({error:"Paket soal belum tersedia."});
  const code=makeCode(); const record={code,title:title||`${assessment||"Asesmen"} ${subject||""} Kelas ${grade||""}`,school,subject,grade,assessment,questions:questions.map(q=>({question:q.question||q.prompt||"",stimulus:q.stimulus||"",options:q.options||{},answer:q.answer||""})),createdAt:Date.now(),participants:[]};
  publishedAssessments.set(code,record); res.json({code,title:record.title,studentUrl:"/"});
});
app.get("/api/assessments/:code", (req,res)=>{ const a=publishedAssessments.get(String(req.params.code)); if(!a)return res.status(404).json({error:"Kode asesmen tidak ditemukan atau sudah tidak aktif."}); res.json({code:a.code,title:a.title,school:a.school,subject:a.subject,grade:a.grade,questions:a.questions.map(q=>({question:q.question,stimulus:q.stimulus,options:q.options}))}); });
app.get("/api/assessments/:code/status", (req,res)=>{ const a=publishedAssessments.get(String(req.params.code)); if(!a)return res.status(404).json({error:"Asesmen tidak ditemukan."}); res.json({code:a.code,title:a.title,participants:a.participants.map(p=>({name:p.name,className:p.className,status:p.status,flags:p.flags,score:p.score,submittedAt:p.submittedAt}))}); });
app.post("/api/assessments/:code/start", (req,res)=>{ const a=publishedAssessments.get(String(req.params.code)); if(!a)return res.status(404).json({error:"Kode asesmen tidak ditemukan."}); const {name,className,sessionId}=req.body||{}; if(!name||!className||!sessionId)return res.status(400).json({error:"Nama, kelas, dan sesi diperlukan."}); if(a.participants.some(p=>p.sessionId===sessionId|| (p.name.toLowerCase()===name.trim().toLowerCase()&&p.className.toLowerCase()===className.trim().toLowerCase())))return res.status(409).json({error:"Sesi peserta sudah pernah dimulai. Hubungi guru jika perlu bantuan."}); a.participants.push({sessionId,name:name.trim(),className:className.trim(),status:"Mengerjakan",flags:[],answers:[],startedAt:Date.now()}); res.json({ok:true}); });
app.post("/api/assessments/:code/flag", (req,res)=>{ const a=publishedAssessments.get(String(req.params.code)); if(!a)return res.status(404).json({error:"Asesmen tidak ditemukan."}); const p=a.participants.find(x=>x.sessionId===req.body.sessionId); if(!p)return res.status(404).json({error:"Sesi siswa tidak ditemukan."}); const flag=String(req.body.flag||"Peristiwa perlu ditinjau").slice(0,160); if(!p.flags.includes(flag))p.flags.push(flag); res.json({ok:true}); });
app.post("/api/assessments/:code/submit", (req,res)=>{ const a=publishedAssessments.get(String(req.params.code)); if(!a)return res.status(404).json({error:"Asesmen tidak ditemukan."}); const p=a.participants.find(x=>x.sessionId===req.body.sessionId); if(!p)return res.status(404).json({error:"Sesi siswa tidak ditemukan."}); if(p.status!=="Mengerjakan")return res.status(409).json({error:"Sesi sudah ditutup dan tidak dapat dikerjakan ulang."}); p.answers=Array.isArray(req.body.answers)?req.body.answers:[]; const total=a.questions.filter(q=>q.answer).length; const correct=a.questions.reduce((n,q,i)=>n+(q.answer && String(p.answers[i]||"")===String(q.answer)?1:0),0); p.score=total?Math.round(correct/total*100):null; p.status=req.body.reason==="keluar halaman"?"Ditutup otomatis · perlu ditinjau":"Selesai dikirim"; p.submittedAt=Date.now(); p.reason=String(req.body.reason||"Dikirim siswa").slice(0,100); res.json({ok:true,status:p.status,score:p.score}); });

const port = process.env.PORT || 3000;
app.listen(port,()=>console.log(`Asisten Guru AI berjalan di http://localhost:${port}`));
