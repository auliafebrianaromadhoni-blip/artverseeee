# RuangGuru AI — Asisten Guru Berbasis AI

Prototipe web untuk membantu guru:
- menyusun draf modul ajar dari CP, ATP, materi, kelas, dan pendekatan pembelajaran;
- menghasilkan paket asesmen formatif/sumatif dengan pilihan LOTS/HOTS, bentuk, jumlah soal, stimulus, kunci dan indikator;
- mengoreksi pilihan ganda berdasarkan kunci jawaban;
- mengimpor respons siswa dari CSV dan mengekspor rekap ke Excel `.xlsx` (atau CSV jika server ekspor tidak tersedia).

## Jalankan di komputer
1. Pasang Node.js versi LTS.
2. Ekstrak ZIP.
3. Buka terminal pada folder proyek, lalu jalankan `npm install`.
4. Salin `.env.example` menjadi `.env` dan isi `OPENAI_API_KEY` jika ingin memakai generasi AI sungguhan. Atur juga `OPENAI_MODEL` bila perlu.
5. Jalankan `npm start`, lalu buka `http://localhost:3000`.

Jika tidak ada API key, aplikasi tetap dapat dicoba dalam **mode demo**. Isi demo hanya contoh struktur/kerangka, bukan soal yang benar-benar dihasilkan AI sesuai CP/ATP. API key hanya disimpan di environment server, jangan di frontend atau repositori publik.

## Format cetak dan modul acuan
- **Cetak soal:** lembar siswa memakai kop sekolah, judul penilaian/mata pelajaran/kelas, kolom Nama-Kelas-No. Absen, petunjuk, nomor soal, serta opsi A–E. Tata letak cetak menggunakan dua kolom seperti contoh PTS yang diberikan. Kunci, pembahasan, level kognitif, dan indikator tidak ikut tercetak pada lembar siswa.
- **Modul ajar:** instruksi AI diarahkan mengikuti struktur dokumen modul yang diberikan: identitas mapel, CP dan elemen, dimensi profil lulusan, desain pembelajaran, tujuan/indikator, praktik pedagogis, pendekatan-metode-strategi, langkah per pertemuan, asesmen dan rubrik, diferensiasi/tindak lanjut, media/sumber, serta refleksi. Integrasi STEM hanya digunakan jika relevan dengan materi.
- Kop sekolah dan alamat bawaan dapat diedit pada kode/keluaran bila sekolah berbeda. Periksa pratinjau cetak dan pilih ukuran kertas A4 pada dialog printer.
- Tombol **Cetak / PDF** membuka dialog cetak browser; pilih **Save as PDF** untuk menyimpan PDF.

## Batasan prototipe
- Belum ada login, database permanen, atau multiakun guru; data rekap tersimpan di sesi browser sampai halaman ditutup/dimuat ulang.
- Koreksi otomatis saat ini untuk pilihan ganda objektif. Uraian memerlukan rubrik dan penilaian guru; fitur penilaian uraian berbantuan AI masih perlu dikembangkan dan divalidasi.
- Fitur ekspor `.xlsx` memakai backend. Jika halaman dibuka langsung sebagai file HTML tanpa `npm start`, ekspor akan turun ke CSV.
- Sebelum digunakan resmi, lakukan uji coba, verifikasi keluaran AI, keamanan data siswa, dan kesesuaian dengan kebijakan sekolah.


## Database satu sekolah (Supabase)
Folder `database/schema.sql` berisi skema PostgreSQL untuk satu sekolah: profil guru, modul ajar, paket asesmen, siswa, butir soal, sesi asesmen, jawaban, hasil nilai, dan riwayat AI. Database ini belum otomatis terhubung ke tampilan prototipe; skema perlu diterapkan di Supabase dan frontend/backend perlu diintegrasikan serta diuji.

1. Buat proyek di Supabase.
2. Buka **SQL Editor**, tempel dan jalankan `database/schema.sql`.
3. Salin Project URL dan API keys ke environment server sesuai `.env.example`.
4. Buat akun guru di Authentication, lalu buat profil pada `public.profiles` dengan ID yang sama.
5. Jangan membagikan `SUPABASE_SERVICE_ROLE_KEY`; key tersebut hanya boleh berada di server.
6. Uji kebijakan Row Level Security sebelum menyimpan data siswa nyata.

**Penting:** skema database telah disiapkan, tetapi login, sinkronisasi CRUD dari antarmuka, dan pemetaan guru ke kelas belum terhubung dalam prototipe ini. Jangan gunakan untuk data siswa nyata sebelum integrasi autentikasi dan uji keamanan selesai.

## Asesmen siswa melalui smartphone (prototipe)
- Guru membuat paket soal pada menu **Generator Asesmen AI**, lalu memilih **Terbitkan untuk siswa**. Sistem menampilkan kode 6 digit.
- Siswa membuka alamat aplikasi yang sama pada smartphone, memilih menu **Asesmen Siswa**, memasukkan kode, nama, kelas, dan memberi izin kamera.
- Pratinjau kamera depan ditampilkan di perangkat siswa. Pada prototipe ini video tidak direkam atau dikirim ke server dan **belum ada model AI pengenal wajah/gerakan**. Sistem hanya mencatat kejadian halaman menjadi tidak aktif serta menutup sesi otomatis jika event browser terdeteksi.
- Status dan nilai objektif peserta dapat dipantau pada menu **Asesmen Siswa** milik guru. Status “perlu ditinjau” bukan bukti pasti kecurangan; notifikasi browser, panggilan, perpindahan aplikasi, atau kendala teknis dapat memicu kejadian serupa.
- Kamera umumnya hanya tersedia pada **HTTPS** (atau localhost saat uji coba). Jangan gunakan `file://` untuk pengujian kamera.

### Batasan penting sebelum digunakan untuk penilaian resmi
Ini masih prototipe: data asesmen tersimpan di memori server dan hilang saat server dimulai ulang; sesi dan kunci peserta belum dilindungi autentikasi sekolah; pencegahan percobaan ulang belum setara sistem ujian terkunci; browser/sistem operasi dapat membatasi deteksi saat aplikasi ditutup paksa atau jaringan putus. Agar siap produksi, integrasikan autentikasi siswa/guru, database persisten (mis. Supabase/Postgres), kebijakan retensi data, HTTPS, audit log, dan uji perangkat lintas smartphone. Sediakan akomodasi alternatif bagi siswa yang tidak dapat atau tidak ingin menggunakan kamera, sesuai kebijakan sekolah dan aturan privasi yang berlaku.
