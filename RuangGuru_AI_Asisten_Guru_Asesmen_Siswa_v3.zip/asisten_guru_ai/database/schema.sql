-- RuangGuru AI — skema database untuk satu sekolah (Supabase/PostgreSQL)
-- Jalankan seluruh skrip ini di Supabase > SQL Editor.
-- Autentikasi memakai Supabase Auth. Jangan menyimpan password sendiri.

create extension if not exists pgcrypto;

-- Profil guru yang terkait dengan akun Supabase Auth.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text,
  role text not null default 'guru' check (role in ('admin','guru')),
  created_at timestamptz not null default now()
);

create table if not exists public.modul_ajar (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references public.profiles(id) on delete cascade,
  judul text not null,
  mata_pelajaran text not null,
  kelas text,
  cp text not null,
  atp text not null,
  materi text,
  alokasi_waktu text,
  pendekatan text,
  isi_modul jsonb not null default '{}'::jsonb,
  status text not null default 'draf' check (status in ('draf','ditinjau','final')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.paket_asesmen (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references public.profiles(id) on delete cascade,
  judul text not null,
  mata_pelajaran text not null,
  kelas text,
  jenis text not null check (jenis in ('Formatif','Sumatif','PTS','PAS','Lainnya')),
  cp text not null,
  atp text not null,
  materi text not null,
  level_kognitif text,
  bentuk_soal text,
  jumlah_soal integer not null default 0 check (jumlah_soal >= 0),
  isi_soal jsonb not null default '{}'::jsonb,
  status text not null default 'draf' check (status in ('draf','ditinjau','diterbitkan','ditutup')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.siswa (
  id uuid primary key default gen_random_uuid(),
  nama text not null,
  kelas text not null,
  nomor_absen integer,
  kode_siswa text,
  aktif boolean not null default true,
  created_at timestamptz not null default now(),
  unique (kelas, nomor_absen)
);

create table if not exists public.butir_soal (
  id uuid primary key default gen_random_uuid(),
  paket_id uuid not null references public.paket_asesmen(id) on delete cascade,
  nomor integer not null,
  stimulus text,
  pertanyaan text not null,
  opsi jsonb not null default '{}'::jsonb,
  kunci text,
  pembahasan text,
  level_kognitif text,
  indikator text,
  bobot numeric not null default 1,
  unique (paket_id, nomor)
);

create table if not exists public.sesi_asesmen (
  id uuid primary key default gen_random_uuid(),
  paket_id uuid not null references public.paket_asesmen(id) on delete cascade,
  kelas text not null,
  dibuka_pada timestamptz,
  ditutup_pada timestamptz,
  batas_waktu_menit integer,
  status text not null default 'draf' check (status in ('draf','aktif','selesai')),
  created_at timestamptz not null default now()
);

create table if not exists public.jawaban_siswa (
  id uuid primary key default gen_random_uuid(),
  sesi_id uuid not null references public.sesi_asesmen(id) on delete cascade,
  siswa_id uuid not null references public.siswa(id) on delete cascade,
  butir_id uuid not null references public.butir_soal(id) on delete cascade,
  jawaban text,
  benar boolean,
  skor numeric,
  umpan_balik text,
  dijawab_pada timestamptz not null default now(),
  unique (sesi_id, siswa_id, butir_id)
);

create table if not exists public.hasil_nilai (
  id uuid primary key default gen_random_uuid(),
  sesi_id uuid not null references public.sesi_asesmen(id) on delete cascade,
  siswa_id uuid not null references public.siswa(id) on delete cascade,
  jumlah_benar integer not null default 0,
  jumlah_soal integer not null default 0,
  nilai numeric not null default 0 check (nilai >= 0 and nilai <= 100),
  batas_tuntas numeric not null default 75,
  status text not null default 'Belum tuntas' check (status in ('Tuntas','Belum tuntas')),
  catatan_guru text,
  dikoreksi_pada timestamptz not null default now(),
  unique (sesi_id, siswa_id)
);

create table if not exists public.riwayat_ai (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references public.profiles(id) on delete cascade,
  jenis text not null check (jenis in ('modul','soal','rubrik','analisis')),
  input_ringkas jsonb not null default '{}'::jsonb,
  hasil jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Indeks untuk pencarian data yang sering digunakan.
create index if not exists idx_modul_created_by on public.modul_ajar(created_by, updated_at desc);
create index if not exists idx_paket_created_by on public.paket_asesmen(created_by, updated_at desc);
create index if not exists idx_paket_kelas on public.paket_asesmen(kelas, jenis);
create index if not exists idx_siswa_kelas on public.siswa(kelas, nama);
create index if not exists idx_hasil_sesi on public.hasil_nilai(sesi_id, kelas);

-- Batasi akses: semua tabel privat untuk pengguna yang sudah login.
alter table public.profiles enable row level security;
alter table public.modul_ajar enable row level security;
alter table public.paket_asesmen enable row level security;
alter table public.siswa enable row level security;
alter table public.butir_soal enable row level security;
alter table public.sesi_asesmen enable row level security;
alter table public.jawaban_siswa enable row level security;
alter table public.hasil_nilai enable row level security;
alter table public.riwayat_ai enable row level security;

-- Satu sekolah: profil yang login boleh membaca profil sendiri.
drop policy if exists "profile self read" on public.profiles;
create policy "profile self read" on public.profiles for select to authenticated using (id = auth.uid());

-- Untuk tahap awal, setiap guru hanya dapat mengelola modul, paket asesmen,
-- dan riwayat AI miliknya. Data siswa/hasil diatur hanya untuk guru login,
-- karena prototipe ini belum memiliki pemetaan kelas-guru yang rinci.
drop policy if exists "teacher owns modules" on public.modul_ajar;
create policy "teacher owns modules" on public.modul_ajar for all to authenticated
using (created_by = auth.uid()) with check (created_by = auth.uid());

drop policy if exists "teacher owns packages" on public.paket_asesmen;
create policy "teacher owns packages" on public.paket_asesmen for all to authenticated
using (created_by = auth.uid()) with check (created_by = auth.uid());

drop policy if exists "teacher owns ai history" on public.riwayat_ai;
create policy "teacher owns ai history" on public.riwayat_ai for all to authenticated
using (created_by = auth.uid()) with check (created_by = auth.uid());

-- Kebijakan sekolah tunggal: guru yang sudah terautentikasi dapat mengelola
-- data siswa dan hasil asesmen. Sebelum dipakai nyata, tambahkan pembatasan
-- berdasarkan penugasan kelas bila guru tidak boleh melihat seluruh kelas.
drop policy if exists "authenticated manage students" on public.siswa;
create policy "authenticated manage students" on public.siswa for all to authenticated
using (true) with check (true);

drop policy if exists "authenticated manage question items" on public.butir_soal;
create policy "authenticated manage question items" on public.butir_soal for all to authenticated
using (exists(select 1 from public.paket_asesmen p where p.id = paket_id and p.created_by = auth.uid()))
with check (exists(select 1 from public.paket_asesmen p where p.id = paket_id and p.created_by = auth.uid()));

drop policy if exists "authenticated manage sessions" on public.sesi_asesmen;
create policy "authenticated manage sessions" on public.sesi_asesmen for all to authenticated
using (exists(select 1 from public.paket_asesmen p where p.id = paket_id and p.created_by = auth.uid()))
with check (exists(select 1 from public.paket_asesmen p where p.id = paket_id and p.created_by = auth.uid()));

drop policy if exists "authenticated manage answers" on public.jawaban_siswa;
create policy "authenticated manage answers" on public.jawaban_siswa for all to authenticated
using (exists(select 1 from public.sesi_asesmen s join public.paket_asesmen p on p.id=s.paket_id where s.id=sesi_id and p.created_by=auth.uid()))
with check (exists(select 1 from public.sesi_asesmen s join public.paket_asesmen p on p.id=s.paket_id where s.id=sesi_id and p.created_by=auth.uid()));

drop policy if exists "authenticated manage grades" on public.hasil_nilai;
create policy "authenticated manage grades" on public.hasil_nilai for all to authenticated
using (exists(select 1 from public.sesi_asesmen s join public.paket_asesmen p on p.id=s.paket_id where s.id=sesi_id and p.created_by=auth.uid()))
with check (exists(select 1 from public.sesi_asesmen s join public.paket_asesmen p on p.id=s.paket_id where s.id=sesi_id and p.created_by=auth.uid()));

-- Trigger untuk memperbarui updated_at.
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;
drop trigger if exists set_modul_updated_at on public.modul_ajar;
create trigger set_modul_updated_at before update on public.modul_ajar for each row execute function public.set_updated_at();
drop trigger if exists set_paket_updated_at on public.paket_asesmen;
create trigger set_paket_updated_at before update on public.paket_asesmen for each row execute function public.set_updated_at();

-- Catatan:
-- 1) Buat pengguna guru melalui Supabase Authentication > Users.
-- 2) Buat profilnya secara eksplisit pada public.profiles dengan id sama dengan auth.users.id.
-- 3) Jangan pernah meletakkan service_role key di browser.
-- 4) Skema ini menyiapkan database; aplikasi frontend perlu dikoneksikan ke Supabase
--    dan autentikasi perlu diuji sebelum digunakan untuk data siswa sungguhan.
